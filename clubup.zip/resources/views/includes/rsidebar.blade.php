   

<h4 class="background: #eae9db;"><u>Total Attendance - </u>{{ $attendancecount }}</h4>
 