@extends('layouts.bootstrap')

@section('content')

    
                       












       



                        <div class="row justify-content-md-center">
                          <div class="col col-lg-2">
                            1 of 3
                          </div>
                          <div class="col-12 col-md-auto">
                            Variable width content
                          </div>
                          <div class="col col-lg-2">
                            3 of 3
                          </div>
                        </div>
                        <div class="row">
                          <div class="col">
                            1 of 3
                          </div>
                          <div class="col-12 col-md-auto">
                            Variable width content
                          </div>
                          <div class="col col-lg-2">
                            3 of 3
                          </div>
                      </div>

                            
                       
        
 
@stop


@section('scripts')

  <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>

   
</script>
  
@stop





  