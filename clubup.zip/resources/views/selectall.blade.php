




@extends('layouts.bootstrap')

@section('content')



<div class="col-md-12">

     <div id="main" class="row">

                    <!-- sidebar content -->
                    <div id="sidebar" class="col-md-3">
                        @include('includes.lsidebar')
                    </div>

                    <!-- main content -->
                    <div id="content " class="col-md-6">
                      
                      <table class="table table-striped pull-left background: #eae9db;">                       
                          
                        <tbody>
                          <tr><td class="pull-left"><strong>Name:<strong></td>
                            <td class="pull-left small"><strong> {{ $members->FIRST_NAME }}, 
                              {{ $members->LAST_NAME }} - {{$members->GVR_NUMBER}}</strong></td>
                         </tr> 

                           <tr class="spacer">  
                            <td class="pull-left"><strong>Address:<strong></td>
                            <td class="pull-left"><strong> {{ $members->PROPERTY_ADDRESS }}</strong></td>                          
                          </tr>

                          <tr class="spacer">  
                            <td class="pull-left"><strong>ZIP:<strong></td>
                            <td class="pull-left"><strong> {{ $members->MAILING_ZIP }}</strong></td>                          
                          </tr>

                          <tr>  
                            <td class="pull-left"><strong>Telephone:<strong></td>
                            <td class="pull-left"><strong> {{ $members->TELEPHONE }}</strong></td>                          
                          </tr>

                           <tr>  
                            <td class="pull-left"><strong>Email:<strong></td>
                            <td class="pull-left"><strong> {{ $members->email }}</strong></td>                          
                          </tr>

                           <tr>  
                            <td class="pull-left"><strong>Membership:<strong></td>
                            <td class="pull-left"><strong> {{ $members->MEMBERSHIP_TYPE }}</strong></td>                          
                          </tr>                          
                          
                          <tr>  
                            <td class="pull-left"><strong>Computer Type:<strong></td>
                            <td class="pull-left"><strong> {{ $members->COMPUTER_TYPE}}</strong></td>                          
                          </tr>

                          <tr>  
                            <td class="pull-left"><strong>Expiration Date:<strong></td>
                            <td class="pull-left"><strong> {{ $members->EXPIRE_DATE}}</strong></td>                          
                          </tr>

                          <tr>  
                            <td class="pull-left"><strong>Change Date:<strong></td>
                            <td class="pull-left"><strong> {{ $members->DATE_CHANGED}}</strong></td>                          
                          </tr>



                          {{--@if (($members->MEMBERSHIP_TYPE) == 'F')

                          <tr>  
                            <td class="pull-left"><strong>Primary Member:<strong></td>
                            <td class="pull-left"><strong> {{ $familyprimary[0]->LAST_NAME }}, {{ $familyprimary[0]->FIRST_NAME}} - {{ $familyprimary[0]->GVR_NUMBER}}</strong></td>                          
                          </tr>

                          @endif

                          --}}

                           
                           
                          
                        </tbody>
                      </table>

                    </div>

                     <!-- sidebar content -->
                      <div id="sidebar" class="col-md-3">
                        @include('includes.rsidebar')
                      </div>
                       
              </div>


             

     </div>
                  

</div>

@stop





 

@section('scripts')

  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" />
   

   

          

     
    
  
      
  </script>
  
@stop





  