$( document ).ready(function() {

    //console.log( "ready!" );



    $( "#selectitem" ).change(function() {
        console.log( "ready!1" );
    });

    


});