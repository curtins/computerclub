<?php $__env->startSection('partials'); ?>

  <div class="row">

                           <div class="  lead"><b>Last Name or GVR#</b></div>


                      </div>    

<?php $__env->stopSection(); ?>