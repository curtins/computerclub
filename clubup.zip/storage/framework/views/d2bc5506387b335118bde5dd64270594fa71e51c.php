   

<h4 class="background: #eae9db;"><u>Total Attendance - </u><?php echo e($attendancecount); ?></h4>
 