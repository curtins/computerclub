<?php $__env->startSection('content'); ?>

<div class="col-md-12">

               
                <?php echo e($members->LAST_NAME); ?>

                
                   



                <div id="row1">

                          <div class="row">

                            <div class="  lead">test</div>

                          </div>  

                  </div>



                  <div id="row2">

                          <div class="row">

                            <div class="  lead">   </div>

                          </div>  

                  </div>

</div>

<?php $__env->stopSection(); ?>





 

<?php $__env->startSection('scripts'); ?>

  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" />
   

   

          

     
    
  
      
  </script>
  
<?php $__env->stopSection(); ?>





  
<?php echo $__env->make('layouts.bootstrap', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>