 
<h4 class="background: #eae9db;"><u>Attendance</u></h4>
 
<?php if(!$attendance->isEmpty()): ?>

    <?php $__currentLoopData = $attendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendances): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>      
        <p class="small"><?php echo e(Carbon\Carbon::parse($attendances->DATE_ATTENDED)->format('m-d-Y')); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
   <p>No Attendance</p>

<?php endif; ?>

<br>

<h4><u>Transactions</u></h4>
 
<?php if(!$transaction->isEmpty()): ?>

    <?php $__currentLoopData = $transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transactions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p class="small"  ><?php echo e($transactions->TRAN_TYPE); ?> - <?php echo e(Carbon\Carbon::parse($transactions->tran_date)->format('m-d-Y')); ?> - <?php echo e(number_format($transactions->TRAN_AMT,2)); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
   <p>No Transactions</p>
<?php endif; ?>
  


   
   
 











