<?php $__env->startSection('content'); ?>



<div class="col-md-12">

     <div id="main" class="row">

                    <!-- sidebar content -->
                    <div id="sidebar" class="col-md-3">
                        <?php echo $__env->make('includes.lsidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>

                    <!-- main content -->
                    <div id="content " class="col-md-6">
                      
                      <table class="table table-striped pull-left background: #eae9db;">                       
                          
                        <tbody>
                          <tr><td class="pull-left"><strong>Name:<strong></td>
                            <td class="pull-left small"><strong> <?php echo e($members->FIRST_NAME); ?>, 
                              <?php echo e($members->LAST_NAME); ?> - <?php echo e($members->GVR_NUMBER); ?></strong></td>
                         </tr> 

                           <tr class="spacer">  
                            <td class="pull-left"><strong>Address:<strong></td>
                            <td class="pull-left"><strong> <?php echo e($members->PROPERTY_ADDRESS); ?></strong></td>                          
                          </tr>

                          <tr class="spacer">  
                            <td class="pull-left"><strong>ZIP:<strong></td>
                            <td class="pull-left"><strong> <?php echo e($members->MAILING_ZIP); ?></strong></td>                          
                          </tr>

                          <tr>  
                            <td class="pull-left"><strong>Telephone:<strong></td>
                            <td class="pull-left"><strong> <?php echo e($members->TELEPHONE); ?></strong></td>                          
                          </tr>

                           <tr>  
                            <td class="pull-left"><strong>Email:<strong></td>
                            <td class="pull-left"><strong> <?php echo e($members->email); ?></strong></td>                          
                          </tr>

                           <tr>  
                            <td class="pull-left"><strong>Membership:<strong></td>
                            <td class="pull-left"><strong> <?php echo e($members->MEMBERSHIP_TYPE); ?></strong></td>                          
                          </tr>                          
                          
                          <tr>  
                            <td class="pull-left"><strong>Computer Type:<strong></td>
                            <td class="pull-left"><strong> <?php echo e($members->COMPUTER_TYPE); ?></strong></td>                          
                          </tr>

                          <tr>  
                            <td class="pull-left"><strong>Expiration Date:<strong></td>
                            <td class="pull-left"><strong> <?php echo e($members->EXPIRE_DATE); ?></strong></td>                          
                          </tr>

                          <tr>  
                            <td class="pull-left"><strong>Change Date:<strong></td>
                            <td class="pull-left"><strong> <?php echo e($members->DATE_CHANGED); ?></strong></td>                          
                          </tr>



                          

                           
                           
                          
                        </tbody>
                      </table>

                    </div>

                     <!-- sidebar content -->
                      <div id="sidebar" class="col-md-3">
                        <?php echo $__env->make('includes.rsidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                      </div>
                       
              </div>


             

     </div>
                  

</div>

<?php $__env->stopSection(); ?>





 

<?php $__env->startSection('scripts'); ?>

  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" />
   

   

          

     
    
  
      
  </script>
  
<?php $__env->stopSection(); ?>





  
<?php echo $__env->make('layouts.bootstrap', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>